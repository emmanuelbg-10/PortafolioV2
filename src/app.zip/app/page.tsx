import NavBar from "./NavBar";
import Projects from "./Projects";
import Presentation from "./Presentation";
import "./globals.css";

export default function Home() {
  return (
    <div className="container">
      <header className="header mt-100">
        <NavBar />
      </header>
      <main className="content ">
        <Presentation />
        <Projects />
      </main>
      <footer className="text-center py-4">© {new Date().getFullYear()} Portafolio Emmanuel</footer>
    </div>
  );
}
