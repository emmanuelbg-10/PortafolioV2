"use client"; // Marca este componente como un Client Component

import { useState } from "react";

export default function Presentation() {
  return (
    <section className="presentation">
      <h1 className="text-3xl font-semibold">Hola</h1>
      <p className="text-lg">
        Soy Emmanuel, un desarrollador web
        <br /> que le encanta aprender cosas nuevas.
      </p>
    </section>
  );
}
