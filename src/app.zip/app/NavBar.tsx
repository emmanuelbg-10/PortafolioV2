"use client";

import { useState, useEffect } from "react";
import ThemeToggle from "./ThemeToggle";

export default function NavBar() {
  const [menuOpen, setMenuOpen] = useState(false);

  // Manejar la clase en <body> cuando se abre el menú
  useEffect(() => {
    if (menuOpen) {
      document.body.classList.add("menu-open");
    } else {
      document.body.classList.remove("menu-open");
    }
  }, [menuOpen]);

  return (
    <nav className="navbar fixed top-0 left-0 w-full bg-[var(--navbar-background)] shadow-md z-50 flex items-center justify-between px-4 h-16">
      {/* Botón de hamburguesa (solo en móviles) */}
      <button
        onClick={() => setMenuOpen(!menuOpen)}
        className="menu-icon flex flex-col gap-2 cursor-pointer md:hidden"
      >
        <span
          className={`block w-6 h-0.5 bg-[var(--text-color)] transition-transform ${
            menuOpen ? "rotate-45 translate-y-1.5" : ""
          }`}
        ></span>
        <span
          className={`block w-6 h-0.5 bg-[var(--text-color)] transition-opacity ${
            menuOpen ? "opacity-0" : ""
          }`}
        ></span>
        <span
          className={`block w-6 h-0.5 bg-[var(--text-color)] transition-transform ${
            menuOpen ? "-rotate-45 -translate-y-1.5" : ""
          }`}
        ></span>
      </button>

      {/* Menú */}
      <ul
        className={`menu fixed top-16 left-0 w-full bg-[var(--navbar-background)] shadow-md flex flex-col gap-2 py-4 z-40 transition-all duration-300
      ${menuOpen ? "flex opacity-100 translate-y-0" : "hidden opacity-0 -translate-y-4"} 
      md:flex md:flex-row md:static md:w-full md:shadow-none md:opacity-100 md:translate-y-0 md:items-center md:justify-center md:gap-4`}
      >
        <li className="text-center">
          <a
            href="#conocimientos"
            className="text-[var(--text-color)] hover:text-[var(--hover-color)] transition-colors duration-300"
          >
            Conocimientos
          </a>
        </li>
        <li className="text-center">
          <a
            href="#projects"
            className="text-[var(--text-color)] hover:text-[var(--hover-color)] transition-colors duration-300"
          >
            Proyectos
          </a>
        </li>
        <li className="text-center">
          <a
            href="#contact"
            className="text-[var(--text-color)] hover:text-[var(--hover-color)] transition-colors duration-300"
          >
            Contacto
          </a>
        </li>
      </ul>

      {/* Botón de cambio de tema (alineado a la derecha) */}
      <div className="ml-auto md:ml-0">
        <ThemeToggle />
      </div>
    </nav>
  );
}
