// app/about/page.tsx
export default function About() {
  return (
    <section>
      <h1>Sobre mí</h1>
      <p>Hola, soy un desarrollador web apasionado por crear soluciones innovadoras.</p>
    </section>
  );
}
